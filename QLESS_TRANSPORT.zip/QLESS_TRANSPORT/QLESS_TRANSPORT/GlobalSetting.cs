﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Net;
using System.Net.Sockets;

namespace globalSettings
{
    public class GlobalSetting
    {
        public string UserID = "";
        public string DB_Bookkeeping = ConfigurationManager.AppSettings["Bookkeeping"].ToString();
        public string GetCalendar = ConfigurationManager.AppSettings["GetCalendar"].ToString();
        public string GetBranch = ConfigurationManager.AppSettings["GetBranch"].ToString();
        public string BK_SP = ConfigurationManager.AppSettings["BK_SP"].ToString();
        public string GetUser = ConfigurationManager.AppSettings["GetUser"].ToString();
        public string GetAllEmp = ConfigurationManager.AppSettings["GetAllEmp"].ToString();
        public string Appname1 = "Snapshot";
        public string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an IPv4 address in the system!");
        }
    }
}